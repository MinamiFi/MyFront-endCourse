let add = document.getElementById('add');//获取‘添加’按钮节点
let input = document.querySelectorAll('.shuru>input');//获取所有输入框的节点
// console.log(input[0]);
// console.log(add);
let table= document.getElementById('biaoge');//获取表格节点
let tableData = [];//储存表格数据的数组
//读取已保存的数据,若存在则渲染数据的数组
if (localStorage.getItem('tableData')) {
    //用于读取之前保存在本地存储中的数据，如果存在，则通过 JSON.parse() 方法将字符串转换为对象数组并保存在 tableData 变量中。
    //在 localStorage 中存储的数据必须是字符串格式，而 JavaScript 对象和数组等数据类型是不能直接存储到 localStorage 中的，需要先将其转化为字符串格式，然后再存储到 localStorage 中。
    tableData = JSON.parse(localStorage.getItem('tableData'));// 这里的'tableData' 为键名
    renderTableData(tableData);
  }

add.onclick = function(){
    let tr1 = document.createElement('tr');//创造新增行节点
    table.appendChild(tr1);//将新增行接入父节点
    let len = input.length;//获得input数组长度
    //以下为增加内容代码
    for(let i = 0; i < len; i++)
    {
        var td = document.createElement('td');//创造本行i列的节点
        td.innerHTML=input[i].value;//获取输入值
        tr1.appendChild(td); //接入父节点
    }
    var tdl = document.createElement('td');//创建"删除/修改"的格子节点
    tr1.appendChild(tdl);
    let del = document.createElement('button');//创建删除按钮节点
    del.innerHTML="删除";
    tdl.appendChild(del);
    // let xiu = document.createElement('button');//创建修改按钮节点
    // xiu.innerHTML = "修改";
    // tdl.appendChild(xiu);

    //以下为删除代码
    del.onclick = function(){
        // 获取所在行的索引
        const rowIndex = tr1.rowIndex - 1;
        // 从数组中删除对应的数据项
        tableData.splice(rowIndex, 1);
        // 更新 localStorage 中存储的数据
        localStorage.setItem('tableData', JSON.stringify(tableData));
        // 从表格中删除对应的行
        tr1.remove();
    }

    // 将新增的数据项存储到数组中
    tableData.push({
    character: input[0].value,
    eye: input[1].value,
    weapon: input[2].value,
    seat: input[3].value
    });

    // 更新 localStorage 中存储的数据
    localStorage.setItem('tableData', JSON.stringify(tableData));
    //清空输入框内容，方便下一次输入
    for(let i=0;i<len;i++)
    {
        input[i].value = '';
    }
}
function renderTableData(data) {
    for (let i = 0; i < data.length; i++) {
      let tr1 = document.createElement('tr');
      table.appendChild(tr1);
  
      let td1 = document.createElement('td');
      td1.innerHTML = data[i].character;
      tr1.appendChild(td1);
  
      let td2 = document.createElement('td');
      td2.innerHTML = data[i].eye;
      tr1.appendChild(td2);
  
      let td3 = document.createElement('td');
      td3.innerHTML = data[i].weapon;
      tr1.appendChild(td3);
  
      let td4 = document.createElement('td');
      td4.innerHTML = data[i].seat;
      tr1.appendChild(td4);
  
      var tdl = document.createElement('td');
      tr1.appendChild(tdl);
      let del = document.createElement('button');
      del.innerHTML = "删除";
      tdl.appendChild(del);
      //以下这段代码的作用是在删除表格中的行后，同步将该行所对应的数据项从本地存储中删除，以确保刷新网页后数据的一致性。
      del.onclick = function() {
        const rowIndex = tr1.rowIndex - 1;
        tableData.splice(rowIndex, 1);
        localStorage.setItem('tableData', JSON.stringify(tableData));
        tr1.remove();
      }
    }
  }
    //以下为修改代码
   /* xiu.onclick = function(){
        tr1.remove();
        let tr2 = document.createElement('tr');
        table.appendChild(tr2);
        let inputx = new Array(len);
        let holdxg = new Array(len);
        for(let i = 0; i < len; i++)
        {
            let td = document.createElement('td');
            inputx[i] = document.createElement('input');
            inputx.placeholder = input[i].value;
            td.appendChild(inputx[i]);
            tr2.appendChild(td);
            
        }
        var tdl = document.createElement('td');//创建"删除/保存"的格子节点
        tr2.appendChild(tdl);
        let del2 = document.createElement('button');//创建删除按钮节点
        del2.innerHTML="删除";
        tdl.appendChild(del2);
        let bc = document.createElement('button');//创建保存按钮节点
        bc.innerHTML = "保存";
        tdl.appendChild(bc);
        for(let i=0;i<len;i++)//将新输入的内容储存
        {
            holdxg[i] = inputx[i].value;
        }

        del2.onclick = function(){
            tr2.remove();
        }
        //以下为保存代码
        bc.onclick = function(){
            tr2.remove();
            let tr3 = document.createElement('tr');
            table.appendChild(tr3);
            for(let i = 0; i < len; i++)
            {
                let td = document.createElement('td');
                td.innerHTML = holdxg[i];
                tr3.appendChild(td);
            }

        }

    }*/
